# Voliboli PDF Scraper

## Tests

You can run test from the root of this repository using:

    pipenv run python tests/test_main.py

## Distribute

You can install this package locally from any other project using:

    pip install -e /path/to/root

where `root` is the top-level directory of this project.
